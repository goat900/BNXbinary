# BNXbinary

A responsive, dark red/charcoal binary-trading interface prototype inspired by the supplied reference video.

## Included
- Dashboard layout with sidebar navigation
- Indicative chart visual (generated locally; not market data)
- Simulated Rise/Fall practice trades and demo statistics
- Quick-trade form, recent activity and digit distribution preview
- Deriv connection setup placeholder
- Responsive desktop and mobile layout

## Important status
This project is a **front-end preview only**. It does not connect to Deriv, fetch live prices, place real contracts, process deposits/withdrawals, or provide predictive AI signals. The chart and trade outcomes are simulated. Do not enter a Deriv password, API token, or other secret into this preview.

Before real account integration:
1. Register your application through Deriv's official developer process and configure the exact allowed redirect URL.
2. Implement OAuth authorization-code flow with PKCE and validate state on a secure backend.
3. Keep secrets and token exchange on the server; never put client secrets or long-lived tokens in browser JavaScript.
4. Use Deriv's current API documentation and test on a demo account first.
5. Add server-side authorization, input validation, rate limiting, audit logs, error handling, and explicit user confirmation before trading.
6. Have the finished product reviewed for applicable legal, regulatory, privacy and consumer-protection requirements.

## Run locally
Open `index.html` in a modern browser. For a local web server, run:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy with GitHub + Cloudflare Pages
1. Create a GitHub repository named `BNXbinary`.
2. Upload all files in this folder (`index.html`, `styles.css`, `app.js`, `README.md`) to the repository root.
3. In Cloudflare, open **Workers & Pages → Create → Pages → Connect to Git**.
4. Select the `BNXbinary` repository.
5. Framework preset: **None**. Build command: leave blank. Build output directory: `/` (repository root).
6. Deploy. Cloudflare will provide a `*.pages.dev` URL.
7. For updates, commit and push changes to GitHub; Cloudflare Pages will redeploy automatically.

## Project structure
```text
BNXbinary/
├── index.html
├── styles.css
├── app.js
└── README.md
```
